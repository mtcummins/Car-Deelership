/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarDealershipModel;

import java.math.BigDecimal;
import java.util.Objects;

/**
 *
 * @author michc
 */
public class SalesInfo {
    private int salesInfoId;
    private String name;
    private String phone;
    private String email;
    private String street1;
    private String street2;
    private String city;
    private String state;
    private int ZipCode;
    private BigDecimal purchasePrice;

    public SalesInfo(int salesInfoId, String name, String phone, String email, String street1, String street2, String city, String state, int ZipCode, BigDecimal purchasePrice) {
        this.salesInfoId = salesInfoId;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.street1 = street1;
        this.street2 = street2;
        this.city = city;
        this.state = state;
        this.ZipCode = ZipCode;
        this.purchasePrice = purchasePrice;
    }
    
     public SalesInfo(int salesInfoId, String name, String phone, String email, String street1, String city, String state, int ZipCode, BigDecimal purchasePrice) {
        this.salesInfoId = salesInfoId;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.street1 = street1;
        this.city = city;
        this.state = state;
        this.ZipCode = ZipCode;
        this.purchasePrice = purchasePrice;
    }
    
    public SalesInfo(){
        
    }

    public int getSalesInfoId() {
        return salesInfoId;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getStreet1() {
        return street1;
    }

    public String getStreet2() {
        return street2;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public int getZipCode() {
        return ZipCode;
    }

    public BigDecimal getPurchasePrice() {
        return purchasePrice;
    }

    public void setSalesInfoId(int salesInfoId) {
        this.salesInfoId = salesInfoId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setStreet1(String street1) {
        this.street1 = street1;
    }

    public void setStreet2(String street2) {
        this.street2 = street2;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setZipCode(int ZipCode) {
        this.ZipCode = ZipCode;
    }

    public void setPurchasePrice(BigDecimal purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + this.salesInfoId;
        hash = 41 * hash + Objects.hashCode(this.name);
        hash = 41 * hash + Objects.hashCode(this.phone);
        hash = 41 * hash + Objects.hashCode(this.email);
        hash = 41 * hash + Objects.hashCode(this.street1);
        hash = 41 * hash + Objects.hashCode(this.street2);
        hash = 41 * hash + Objects.hashCode(this.city);
        hash = 41 * hash + Objects.hashCode(this.state);
        hash = 41 * hash + this.ZipCode;
        hash = 41 * hash + Objects.hashCode(this.purchasePrice);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SalesInfo other = (SalesInfo) obj;
        if (this.salesInfoId != other.salesInfoId) {
            return false;
        }
        if (this.ZipCode != other.ZipCode) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.phone, other.phone)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.street1, other.street1)) {
            return false;
        }
        if (!Objects.equals(this.street2, other.street2)) {
            return false;
        }
        if (!Objects.equals(this.city, other.city)) {
            return false;
        }
        if (!Objects.equals(this.state, other.state)) {
            return false;
        }
        if (!Objects.equals(this.purchasePrice, other.purchasePrice)) {
            return false;
        }
        return true;
    }
    
    
}
