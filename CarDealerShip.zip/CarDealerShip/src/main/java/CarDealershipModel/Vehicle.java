/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarDealershipModel;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author michc
 */
public class Vehicle {
    private int vehicleId;
    private Date year;
    private String make;
    private String model;
    private String bodyStyle;
    private String trans;
    private String color;
    private String interior;
    private int mileage;
    private int vinNum;
    private BigDecimal salePrice;
    private BigDecimal msrp;
    private String details;
    private String used;

    public Vehicle(int vehicleId, Date year, String make, String model, String bodyStyle, String trans, String color, String interior, int mileage, int vinNum, BigDecimal salePrice, BigDecimal msrp, String details, String used) {
        this.vehicleId = vehicleId;
        this.year = year;
        this.make = make;
        this.model = model;
        this.bodyStyle = bodyStyle;
        this.trans = trans;
        this.color = color;
        this.interior = interior;
        this.mileage = mileage;
        this.vinNum = vinNum;
        this.salePrice = salePrice;
        this.msrp = msrp;
        this.details = details;
        this.used = used;
    }

    public Vehicle(){
        
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public Date getYear() {
        return year;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public String getBodyStyle() {
        return bodyStyle;
    }

    public String getTrans() {
        return trans;
    }

    public String getColor() {
        return color;
    }

    public String getInterior() {
        return interior;
    }

    public int getMileage() {
        return mileage;
    }

    public int getVinNum() {
        return vinNum;
    }

    public BigDecimal getSalePrice() {
        return salePrice;
    }

    public BigDecimal getMsrp() {
        return msrp;
    }

    public String getDetails() {
        return details;
    }

    public String getUsed() {
        return used;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public void setYear(Date year) {
        this.year = year;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setBodyStyle(String bodyStyle) {
        this.bodyStyle = bodyStyle;
    }

    public void setTrans(String trans) {
        this.trans = trans;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setInterior(String interior) {
        this.interior = interior;
    }

    public void setMileage(int mileage) {
        this.mileage = mileage;
    }

    public void setVinNum(int vinNum) {
        this.vinNum = vinNum;
    }

    public void setSalePrice(BigDecimal salePrice) {
        this.salePrice = salePrice;
    }

    public void setMsrp(BigDecimal msrp) {
        this.msrp = msrp;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public void setUsed(String used) {
        this.used = used;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + this.vehicleId;
        hash = 89 * hash + Objects.hashCode(this.year);
        hash = 89 * hash + Objects.hashCode(this.make);
        hash = 89 * hash + Objects.hashCode(this.model);
        hash = 89 * hash + Objects.hashCode(this.bodyStyle);
        hash = 89 * hash + Objects.hashCode(this.trans);
        hash = 89 * hash + Objects.hashCode(this.color);
        hash = 89 * hash + Objects.hashCode(this.interior);
        hash = 89 * hash + this.mileage;
        hash = 89 * hash + this.vinNum;
        hash = 89 * hash + Objects.hashCode(this.salePrice);
        hash = 89 * hash + Objects.hashCode(this.msrp);
        hash = 89 * hash + Objects.hashCode(this.details);
        hash = 89 * hash + Objects.hashCode(this.used);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Vehicle other = (Vehicle) obj;
        if (this.vehicleId != other.vehicleId) {
            return false;
        }
        if (this.mileage != other.mileage) {
            return false;
        }
        if (this.vinNum != other.vinNum) {
            return false;
        }
        if (!Objects.equals(this.make, other.make)) {
            return false;
        }
        if (!Objects.equals(this.model, other.model)) {
            return false;
        }
        if (!Objects.equals(this.bodyStyle, other.bodyStyle)) {
            return false;
        }
        if (!Objects.equals(this.trans, other.trans)) {
            return false;
        }
        if (!Objects.equals(this.color, other.color)) {
            return false;
        }
        if (!Objects.equals(this.interior, other.interior)) {
            return false;
        }
        if (!Objects.equals(this.details, other.details)) {
            return false;
        }
        if (!Objects.equals(this.used, other.used)) {
            return false;
        }
        if (!Objects.equals(this.year, other.year)) {
            return false;
        }
        if (!Objects.equals(this.salePrice, other.salePrice)) {
            return false;
        }
        if (!Objects.equals(this.msrp, other.msrp)) {
            return false;
        }
        return true;
    }
    
    
    
}
