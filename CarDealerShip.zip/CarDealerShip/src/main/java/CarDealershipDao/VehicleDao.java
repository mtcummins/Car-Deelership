/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarDealershipDao;

import CarDealershipModel.Vehicle;
import java.util.List;

/**
 *
 * @author michc
 */
public interface VehicleDao {
    
    Vehicle addVehicle(Vehicle vehicle);
    
    Vehicle updateVehicle(Vehicle vehicle);
    
    List<Vehicle> getAllVehiclesByMake(String vehicleMake);
    
    List<Vehicle> getAllVehiclesByModel(String vehicleModel);
    
    List<Vehicle> getAllVehiclesByYear(String vehicleYear);
    
    List<Vehicle> getAllNewVehicles();
    
    List<Vehicle> getAllUsedVehicles();
    
    Vehicle getVehicle(int vehicleId);
    
    public void deleteVehicle(int vehicleId);
}
