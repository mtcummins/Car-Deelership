/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarDealershipDao;

import CarDealershipModel.Vehicle;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author michc
 */
public class VehicleDaoImpl implements VehicleDao{

    @Autowired
    JdbcTemplate jdbc;
    
    BigDecimal defaultStartPrice = new BigDecimal("0.00");
    BigDecimal defaultEndPrice = new BigDecimal("1000000.00");
    
    Date defaultStartYear = new Date("01-01-1981");
    Date defaultEndYear = new Date("01-01-2025");

    public BigDecimal getDefaultStartPrice() {
        return defaultStartPrice;
    }

    public BigDecimal getDefaultEndPrice() {
        return defaultEndPrice;
    }

    public Date getDefaultStartYear() {
        return defaultStartYear;
    }

    public Date getDefaultEndYear() {
        return defaultEndYear;
    }

    public void setDefaultStartPrice(BigDecimal defaultStartPrice) {
        this.defaultStartPrice = defaultStartPrice;
    }

    public void setDefaultEndPrice(BigDecimal defaultEndPrice) {
        this.defaultEndPrice = defaultEndPrice;
    }

    public void setDefaultStartYear(Date defaultStartYear) {
        this.defaultStartYear = defaultStartYear;
    }

    public void setDefaultEndYear(Date defaultEndYear) {
        this.defaultEndYear = defaultEndYear;
    }
    
    @Override
    public Vehicle addVehicle(Vehicle vehicle) {
        final String INSERT_VEHICLE  = "INSERT INTO vehicle(vehicleYear,vehicleMake,vehicleModel,vehicleBodyStyel,vehicleTrans,vehicleColor,vehicleInterior,"
                + "vehicleMilage,vehicleVinNum,vehicleSalePrice,vehicleMsrop,vehicleDetails,vehicleUsed) VALUE (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbc.update(INSERT_VEHICLE,
                vehicle.getYear(),
                vehicle.getMake(),
                vehicle.getModel(),
                vehicle.getBodyStyle(),
                vehicle.getTrans(),
                vehicle.getColor(),
                vehicle.getInterior(),
                vehicle.getMileage(),
                vehicle.getVinNum(),
                vehicle.getSalePrice(),
                vehicle.getMsrp(),
                vehicle.getDetails(),
                vehicle.getUsed());
        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        vehicle.setVehicleId(newId);
        return vehicle;
    }

    @Override
    public Vehicle updateVehicle(Vehicle vehicle) {
        final String UPDATE_VEHICLE  = "UPDATE vehicle set vehicleYear=?,vehicleMake=?,vehicleModel=?,vehicleBodyStyel=?,vehicleTrans=?,vehicleColor=?,vehicleInterior=?,"
                + "vehicleMilage=?,vehicleVinNum=?,vehicleSalePrice=?,vehicleMsrop=?,vehicleDetails=?,vehicleUsed=?) VALUE (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbc.update(UPDATE_VEHICLE,
                vehicle.getVehicleId(),
                vehicle.getYear(),
                vehicle.getMake(),
                vehicle.getModel(),
                vehicle.getBodyStyle(),
                vehicle.getTrans(),
                vehicle.getColor(),
                vehicle.getInterior(),
                vehicle.getMileage(),
                vehicle.getVinNum(),
                vehicle.getSalePrice(),
                vehicle.getMsrp(),
                vehicle.getDetails(),
                vehicle.getUsed());
        return vehicle;
    }

    @Override
    public List<Vehicle> getAllVehiclesByMake(String vehicleMake) {
        final String SELECT_ALL_VEHICLES_BY_MAKE = "SELECT * FROM vehicle WHERE vehcleMake =? AND vehicleYear >="+defaultStartYear+" AND vehicleYear <="+defaultEndYear+"AND vehcleSalePrice >= "+defaultStartPrice+" AND vehcleSalePrice <= "+defaultEndPrice;
        return jdbc.query(SELECT_ALL_VEHICLES_BY_MAKE, new VehicleMapper(),vehicleMake);    
    }

    @Override
    public List<Vehicle> getAllVehiclesByModel(String vehicleModel) {
        final String SELECT_ALL_VEHICLES_BY_MODEL = "SELECT * FROM vehicle WHERE vehicleModel =? AND vehicleYear >="+defaultStartYear+" AND vehicleYear <="+defaultEndYear+"AND vehcleSalePrice >= "+defaultStartPrice+" AND vehcleSalePrice <= "+defaultEndPrice;
        return jdbc.query(SELECT_ALL_VEHICLES_BY_MODEL, new VehicleMapper(),vehicleModel);    
    }

    @Override
    public List<Vehicle> getAllVehiclesByYear(String vehicleYear) {
        final String SELECT_ALL_VEHICLES_BY_YEAR = "SELECT * FROM vehicle WHERE vehicleYear =? AND vehicleYear >="+defaultStartYear+" AND vehicleYear <="+defaultEndYear+"AND vehcleSalePrice >= "+defaultStartPrice+" AND vehcleSalePrice <= "+defaultEndPrice;
        return jdbc.query(SELECT_ALL_VEHICLES_BY_YEAR, new VehicleMapper(),vehicleYear);
    }

    @Override
    public List<Vehicle> getAllNewVehicles() {
        final String SELECT_ALL_NEW_VEHICLES = "SELECT * FROM post WHERE vehicleUsed = New";
        return jdbc.query(SELECT_ALL_NEW_VEHICLES, new VehicleMapper());
    }

    @Override
    public List<Vehicle> getAllUsedVehicles() {
        final String SELECT_ALL_USED_VEHICLES = "SELECT * FROM post WHERE vehicleUsed = Used";
        return jdbc.query(SELECT_ALL_USED_VEHICLES, new VehicleMapper());
    }

    @Override
    public Vehicle getVehicle(int vehicleId) {
        final String SELECT_VEHICLE = "SELECT * FROM post WHERE vehicleId =?";
        return jdbc.queryForObject(SELECT_VEHICLE, new VehicleMapper(),vehicleId);
    }

    @Override
    public void deleteVehicle(int vehicleId) {
        final String DELETE_VEHICLE = "DELETE FROM vehicle WHERE vehicleId =?";
	jdbc.update(DELETE_VEHICLE, vehicleId);
    }
    
    
    
    public static final class VehicleMapper implements RowMapper<Vehicle> {
        
        @Override
        public Vehicle mapRow(ResultSet rs, int index) throws SQLException{
            Vehicle v = new Vehicle();
            v.setVehicleId(rs.getInt("vehicleId"));
            v.setYear(rs.getDate("vehicleYear"));
            v.setMake(rs.getString("vehicleMake"));
            v.setModel(rs.getString("vehicleModel"));
            v.setBodyStyle(rs.getString("vehicleBodyStyle"));
            v.setTrans(rs.getString("vehicleTrans"));
            v.setColor(rs.getString("vehicleColor"));
            v.setInterior(rs.getString("vehicleInterior"));
            v.setMileage(rs.getInt("vehicleMileage"));
            v.setVinNum(rs.getInt("vehicleVinNum"));
            v.setSalePrice(rs.getBigDecimal("vehicleSalePrice"));
            v.setMsrp(rs.getBigDecimal("vehicleMsrp"));
            v.setDetails(rs.getString("vehicleDetails"));
            v.setUsed(rs.getString("vehicleUsed"));
            return v;
        }
    }
}
