/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarDealershipDao;

import CarDealershipModel.SalesInfo;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
/**
 *
 * @author michc
 */
public class SalesInfoDaoImpl implements SalesInfoDao{
    
    @Autowired
    JdbcTemplate jdbc;
    
    @Override
    public SalesInfo addSalesInfo(SalesInfo salesInfo) {
         final String INSERT_SALESINFO  = "INSERT INTO salesInfo(salesInfoName,salesInfoPhone,salesInfoEmail,"
                 + "salesInfoStreetOne,salesInfoStreetTwo,salesInfoCity,salesInfoState,salesInfoZipCode,salesInfoPurchasePrice) VALUE (?,?,?,?,?,?,?,?,?)";
         jdbc.update(INSERT_SALESINFO,
            salesInfo.getName(),
            salesInfo.getPhone(),
            salesInfo.getEmail(),
            salesInfo.getStreet1(),
            salesInfo.getStreet2(),
            salesInfo.getCity(),
            salesInfo.getState(),
            salesInfo.getZipCode(),
            salesInfo.getPurchasePrice());
        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        salesInfo.setSalesInfoId(newId);
        return salesInfo;
    }

    @Override
    public SalesInfo updateSalesInfo(SalesInfo salesInfo) {
        final String UPDATE_SALESINFO  = "UPDATE salesInfoset salesInfoName=?,salesInfoPhone=?,salesInfoEmail=?,"
                 + "salesInfoStreetOne=?,salesInfoStreetTwo=?,salesInfoCity=?,salesInfoState=?,salesInfoZipCode=?,salesInfoPurchasePrice=?";
         jdbc.update(UPDATE_SALESINFO,
                 salesInfo.getSalesInfoId(),
                salesInfo.getName(),
                salesInfo.getPhone(),
                salesInfo.getEmail(),
                salesInfo.getStreet1(),
                salesInfo.getStreet2(),
                salesInfo.getCity(),
                salesInfo.getState(),
                salesInfo.getZipCode(),
                salesInfo.getPurchasePrice());
         return salesInfo;
    }

    @Override
    public SalesInfo getSalesInfo(int salesInfoId) {
        final String GET_SALESINFO = "SELECT * FROM salesInfo WHERE salesInfotId = ?";
        SalesInfo salesInfo = jdbc.queryForObject(GET_SALESINFO, new SalesInfoMapper(),salesInfoId);
        return salesInfo;
    }
    
    public static final class SalesInfoMapper implements RowMapper<SalesInfo> {
        
        @Override
        public SalesInfo mapRow(ResultSet rs, int index) throws SQLException{
            SalesInfo salesInfo = new SalesInfo();
            salesInfo.setSalesInfoId(rs.getInt("salesInfoId"));
            salesInfo.setName(rs.getString("salesInfoName"));
            salesInfo.setPhone(rs.getString("salesInfoPhone"));
            salesInfo.setEmail(rs.getString("salesInfoEmail"));
            salesInfo.setStreet1(rs.getString("salesInfoStreetOne"));
            salesInfo.setStreet2(rs.getString("salesInfoStreetTwo"));
            salesInfo.setCity(rs.getString("salesInfoCity"));
            salesInfo.setState(rs.getString("salesInfoState"));
            salesInfo.setZipCode(rs.getInt("salesInfoZipCode"));
            salesInfo.setPurchasePrice(rs.getBigDecimal("salesInfoPurchasePrice"));
            return salesInfo;
        }
    }
}
