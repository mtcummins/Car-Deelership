/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CarDealershipDao;

import CarDealershipModel.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author michc
 */
public class UserDaoImpl implements UserDao{

    @Autowired
    JdbcTemplate jdbc;
    
    @Override
    public User addPost(User user) {
        final String INSERT_USER  = "INSERT INTO user(userFirstName,userLastName,userEmail,userRole) VALUE (?,?,?,?)";
        jdbc.update(INSERT_USER,
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getRole());
        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        user.setUserId(newId);
        return user;
    }

    @Override
    public User updatePost(User user) {
        final String UPDATE_USER  = "update user set userId=?,userFirstName=?,userLastName=?,userEmail=?,userRole=?";
        jdbc.update(UPDATE_USER,
                user.getUserId(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getRole());
        return user;
    }

    @Override
    public List<User> getAllUsers() {
        final String SELECT_ALL_USERS = "SELECT * FROM user";
        return jdbc.query(SELECT_ALL_USERS, new UserMapper());
    }

    @Override
    public User getUser(int userId) {
        final String GET_USER = "SELECT * FROM user where userId = ?";
        User user = jdbc.queryForObject(GET_USER, new UserMapper(),userId);
        return user;
    }
    
    public static final class UserMapper implements RowMapper<User> {
        
        @Override
        public User mapRow(ResultSet rs, int index) throws SQLException{
            User user = new User();
            user.setUserId(rs.getInt("userId"));
            user.setFirstName(rs.getString("userFirstName"));
            user.setLastName(rs.getString("userLastName"));
            user.setEmail(rs.getString("userEmail"));
            user.setRole(rs.getString("userRole"));
            return user;
        }
    }
}
